﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Navbot.RealtimeApi.Dotnet.SDK.WPF
{
    public class AudioAnimation
    {
        
    }
}
