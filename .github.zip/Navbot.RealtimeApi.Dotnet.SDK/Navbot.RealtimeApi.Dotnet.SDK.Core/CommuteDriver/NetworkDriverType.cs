﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Navbot.RealtimeApi.Dotnet.SDK.Core
{
    public enum NetworkDriverType
    {
        WebSocket,
        WebRTC
    }
}
